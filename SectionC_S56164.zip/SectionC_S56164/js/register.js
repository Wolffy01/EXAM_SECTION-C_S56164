$("#frmRegister").submit(function (e) {
        e.preventDefault();
        e.stopPropagation();
        var email = $("#inputEmail").val();
        if (pass1 === pass2) {
            var datalist = "inputEmail=" + email;
            $.ajax({
                type: "post",
                url: "http://pantairedang.umt.edu.my/iamcontacts/Register",
                data: datalist,
                cache: false,
                success: function (mydata) {
                    var myData = JSON.parse(mydata);
                    if (myData.status === 1) {
                        alert("User already Register");
                    }
                    else {
                        alert("User Successfully Registered");
                    }
                },
                error: function () {
                    console.log("ajax error!");
                    alert("Please contact admin!");
                }
            });